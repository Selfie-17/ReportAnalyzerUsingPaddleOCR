#include<stdio.h>
int func(int start, int end)
{
    int length = end + 1 - start;

    if ((length < 1) || (start < 0) || (end < 0))
        return 0;

    if (length % 3 == 0)
        return func(start + 1, end);

    else if (length % 3 == 1)
        return 1 + func(start, end - 1);

    else
        return func(start + 2, end);
}
int main()
{
    int start = 1, end = 10;

    printf("%d", func(start, end));

    return 0;
}