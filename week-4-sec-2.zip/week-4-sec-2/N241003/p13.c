#include<stdio.h>
int f(int n){
    if(n<=1)
        return 1;
    return f(n-1)+f(n-1);
}
int main(){
    printf("%d",f(5));
    return 0;
}