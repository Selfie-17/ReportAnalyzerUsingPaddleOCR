#include<stdio.h>
int f(int n){
    if(n==0)
        return 0;
    return f(n/2)+n%2;
}
int main(){
    printf("%d",f(13));
    return 0;
}