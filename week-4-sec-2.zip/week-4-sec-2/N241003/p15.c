#include<stdio.h>
void f(int n){
    if(n<=0)
        return;
    f(n/2);
    f(n/2);
    printf("%d",n);
}
int main(){
    int n;
    printf("Enter n: ");
    scanf("%d",&n);
    f(n);
    return 0;
}