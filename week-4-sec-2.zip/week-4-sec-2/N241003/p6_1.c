#include<stdio.h>
int swap(int x, int y)
{
    int temp=x;
    x=y;
    y=temp;
    printf("inside function x=%d,y=%d\n",x,y);
}
int main()
{
    int x,y;
    printf("Enter a two numbers: ");
    scanf("%d %d",&x,&y);
    printf(" before function x=%d,y=%d\n",x,y);
    swap(x,y);
    printf("after functionx=%d,y=%d",x,y);
}