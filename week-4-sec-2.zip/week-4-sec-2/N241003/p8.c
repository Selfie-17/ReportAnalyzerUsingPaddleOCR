#include<stdio.h>
void diamond(int n)
{
    int i,j;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n-i;j++)
            printf(" ");
        for(j=1;j<=i;j++)
            printf("*");
        for(j=1;j<i;j++)
            printf("*");
        printf("\n");
    }
    for(i=1;i<=n-1;i++)
    {
        for(j=1;j<=i;j++)
            printf(" ");
        for(j=1;j<=n-i;j++)
            printf("*");
        for(j=1;j<n-i;j++)
            printf("*");
        printf("\n");
    }
}
int main()
{
    int n;
    printf("Enter number of rows: ");
    scanf("%d",&n);
    diamond(n);
    return 0;
}