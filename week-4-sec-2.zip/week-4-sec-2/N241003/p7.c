#include<stdio.h>
#include<math.h>
int isarmstrong(int i)
{
    int num,remainder,sum,digit,j,s;
    s=i;
    
    digit=0;
    sum=0;
    num=s;
    for(j=s;j!=0;j=j/10)
    {
        digit++;
    }
    
    while(s!=0)
    {
        remainder=s%10;
        sum=sum+pow(remainder,digit);
        s=s/10;
    }
    if(sum==num)
        return 1;
    else
        return 0;
}
int main()
{
    int start,end,i;
    printf("Enter the starting range: ");
    scanf("%d",&start);
    printf("Enter a ending number: ");
    scanf("%d",&end);
    printf("Armstrong numbers between %d and %d are:\n",start,end);
    for(i=start;i<=end;i++)
    {
        if(isarmstrong(i))
            printf("%d\n",i);
    }
    return 0;
}