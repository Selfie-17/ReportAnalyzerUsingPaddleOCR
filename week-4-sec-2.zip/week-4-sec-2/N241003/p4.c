#include<stdio.h>
int sum(int n){
    if(n==0)
        return 0;
    else
        return n+sum(n-1);
}
int main(){
    int n,result;
    printf("Enter a positive integer: ");
    scanf("%d",&n);
    result=sum(n);
    printf("sum of natural numbers=%d",result);
    return 0;
}
